# Milk-Weights-Program


Course: cs400
Semester: Spring 2020
Project name: Milk Weights
Team Members:
1. Shashank Agrawal, lecture 001, and sagrawal8@wisc.edu
2. Max Battle, lecture 002, and mbattle2@wisc.edu
3. Abhinav Bipin, lecture 001, and bipin@wisc.edu
4. JacobMorse, lecture 002, and jdmorse@wisc.edu

 

Which team members were on the same xteam together?
Abhinav Bipin and Shashank Agrawal

Other notes or comments to the grader:
(Description)
Our MilkWeights program interacts with the user to prompt what kind of report the user desires. Once selected, depending on the report type, the user will be prompted for more specific information to display. There are buttons included to show instructions, write an output file, and to close the program. The add, edit, remove, and display buttons do not accurately perform computations yet and are included solely for show. This will all be achieved through JavaFX. 
